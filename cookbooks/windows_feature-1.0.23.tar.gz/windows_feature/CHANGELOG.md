## 1.0.0
 * CI System integration
   
## 0.1.4
 * Corrected a bug in the sample.rb file.

## 0.1.3
 * Corrected a broken link in the README.md.
 * No code changes.

## 0.1.2
 * Improved feature validation in load_current_resource by calling is_feature_available?() method in Mixlibrary::Core::Windows::Features in providers/manage_feature.rb.
 * Updated and corrected README.md formatting.

## 0.1.1
 * Replaced email address in metadata.rb with actual author email address.

## 0.1.0
 * managed_feature LWRP supporting install or remove of windows features and roles.
